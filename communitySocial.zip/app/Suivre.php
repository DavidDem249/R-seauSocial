<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Suivre extends Model 
{

    protected $table = 'suivres';
    public $timestamps = true;

}