<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class User_post extends Model 
{

    protected $table = 'user_posts';
    public $timestamps = true;

}