<!DOCTYPE html>
    <html>
		<head>
            <meta charset="utf-8"/>          
        </head>
		<body>
			<div bgcolor="#ffffff" style="background-color:#ffffff; margin-top:60px;">
				<div style="font-family:Verdana,Arial,Helvetica,sans-serif;font-size:12px;text-align:center;   color:#8c8c8c;margin:0px;width:100%;background-color:#ffffff">
					<table align="center" border="0" cellpadding="0" cellspacing="0" class="m_-523118678635176237w600" style="font-family:Verdana,Arial,Helvetica,sans-serif;font-size:12px;text-align:justify;color:#8c8c8c;margin:auto;width:600px">
							
					    <tbody>
					    	<tr style="line-height:0px">
								<td class="m_-523118678635176237w600" colspan="5" style="font-family:Verdana,Arial,Helvetica,sans-serif;font-size:12px;text-align:justify;color:#8c8c8c;margin:0px;background-color:#91278e" valign="bottom" width="600"><img width="600" height="38"  border="0" ></td></td>
									</tr>
									<tr>
								<td class="m_-523118678635176237w40" style="font-family:Verdana,Arial,Helvetica,sans-serif;font-size:12px;text-align:justify;color:#8c8c8c;margin:0px;background-color:#ebebeb" width="40"></td>
								<td class="m_-523118678635176237w520" colspan="3" height="80" style="font-family:Verdana,Arial,Helvetica,sans-serif;font-size:12px;text-align:left;color:#8c8c8c;margin:0px;background-color:#ebebeb" width="520">
									<strong>​</strong>​​​​​​​​<img width="41" height="41" hspace="10" align="left" alt="-" border="0" src="https://ci6.googleusercontent.com/proxy/hHCBzgPGT4UGJhBHkc1rc-xrL3WB-Ar1Q_TOwSJ4Xn37CB6bpamqkm0ehmmEWcnLcJMGUvZlBqDp_GaDm44bA4-1J27_jD8RXsgg3VsYs-lxLsRY51e2Df5GWppYMuVpT9O84LbCd4956IYKTn54Q-ZRw2JX=s0-d-e1-ft#https://www.carolehofbauer.com/media/com_acymailing/templates/newsletter-4/images/message_icon.png" style="float:left;margin-right:10px" class="CToWUd">
									<h3 style="color:#393939!important;font-size:18px;font-weight:bold;text-align:left;margin:0px;padding-bottom:5px;border-bottom:1px solid #bdbdbd">Changement d'identifiant<span style="display:none">&nbsp;</span>
									</h3>
								</td>
								<td class="m_-523118678635176237w40" style="font-family:Verdana,Arial,Helvetica,sans-serif;font-size:12px;text-align:justify;color:#8c8c8c;margin:0px;background-color:#ebebeb" width="40"></td>
							</tr>
							<tr>
								<td class="m_-523118678635176237w40" style="font-family:Verdana,Arial,Helvetica,sans-serif;font-size:12px;text-align:justify;color:#8c8c8c;margin:0px;background-color:#ebebeb" width="40"></td>
								<td class="m_-523118678635176237w20" style="font-family:Verdana,Arial,Helvetica,sans-serif;font-size:12px;text-align:justify;color:#8c8c8c;margin:0px;background-color:#fff" width="20"></td>
								<td class="m_-523118678635176237w480" height="20" style="font-family:Verdana,Arial,Helvetica,sans-serif;font-size:12px;text-align:justify;color:#8c8c8c;margin:0px;background-color:#fff" width="480"></td>
								<td class="m_-523118678635176237w20" style="font-family:Verdana,Arial,Helvetica,sans-serif;font-size:12px;text-align:justify;color:#8c8c8c;margin:0px;background-color:#fff" width="20"></td>
								<td class="m_-523118678635176237w40" style="font-family:Verdana,Arial,Helvetica,sans-serif;font-size:12px;text-align:justify;color:#8c8c8c;margin:0px;background-color:#ebebeb" width="40"></td>
							</tr>
							<tr>
								<td class="m_-523118678635176237w40" style="font-family:Verdana,Arial,Helvetica,sans-serif;font-size:12px;text-align:justify;color:#8c8c8c;margin:0px;background-color:#ebebeb" width="40"></td>
								<td class="m_-523118678635176237w20" style="font-family:Verdana,Arial,Helvetica,sans-serif;font-size:12px;text-align:justify;color:#8c8c8c;margin:0px;background-color:#fff" width="20"></td>
								<td class="m_-523118678635176237w480" style="font-family:Verdana,Arial,Helvetica,sans-serif;font-size:12px;text-align:left;color:#8c8c8c;margin:0px;background-color:#fff" width="480">
									<p style="font-family:Verdana,Arial,Helvetica,sans-serif;font-size:12px;text-align:justify;color:#8c8c8c;margin:0px">
										La demande de réinitialisation de votre mot de passe a été effectuée avec succès.<br> Vos identifiants sont :
									</p>
									<br>
									<p style="font-family:Verdana,Arial,Helvetica,sans-serif;font-size:13px;margin:0px;color:#91278e">
										<strong>
											Email: {{ $user['email'] }} <br>
											Mot de passe : {{ $code }} 
										</strong>
									</p>
								</td>
								<td class="m_-523118678635176237w20" style="font-family:Verdana,Arial,Helvetica,sans-serif;font-size:12px;text-align:justify;color:#8c8c8c;margin:0px;background-color:#fff" width="20"></td>
								<td class="m_-523118678635176237w40" style="font-family:Verdana,Arial,Helvetica,sans-serif;font-size:12px;text-align:justify;color:#8c8c8c;margin:0px;background-color:#ebebeb" width="40"></td>
							</tr>
							<tr>
									<td class="m_-523118678635176237w40" style="font-family:Verdana,Arial,Helvetica,sans-serif;font-size:12px;text-align:justify;color:#8c8c8c;margin:0px;background-color:#ebebeb" width="40"></td>
									<td class="m_-523118678635176237w20" style="font-family:Verdana,Arial,Helvetica,sans-serif;font-size:12px;text-align:justify;color:#8c8c8c;margin:0px;background-color:#fff" width="20"></td>
									<td class="m_-523118678635176237w480" height="20" style="font-family:Verdana,Arial,Helvetica,sans-serif;font-size:12px;text-align:justify;color:#8c8c8c;margin:0px;background-color:#fff" width="480"></td>
									<td class="m_-523118678635176237w20" style="font-family:Verdana,Arial,Helvetica,sans-serif;font-size:12px;text-align:justify;color:#8c8c8c;margin:0px;background-color:#fff" width="20"></td>
									<td class="m_-523118678635176237w40" style="font-family:Verdana,Arial,Helvetica,sans-serif;font-size:12px;text-align:justify;color:#8c8c8c;margin:0px;background-color:#ebebeb" width="40"></td>
								</tr>
							
								<tr style="line-height:0px">
									<td class="m_-523118678635176237w600" colspan="5" style="font-family:Verdana,Arial,Helvetica,sans-serif;font-size:12px;text-align:justify;color:#8c8c8c;margin:0px;background-color:#91278e" width="600"><p style="font-family:Verdana,Arial,Helvetica,sans-serif;font-size:12px;text-align:justify;color:#fff;text-align:center;margin-bottom:;margin-top:px;background-color:#; height:18px">@2019  SocialCommunity, un réseau social conçu pour vôtre bonheur</p>
									</td>

								</tr>
						</tbody>
					</table>
				</div>
			</div>
		</body>
	</html>






