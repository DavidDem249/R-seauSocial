<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<title>Message</title>
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<meta name="description" content="" />
		<meta name="keywords" content="" />
		<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/animate.css')); ?>">
		<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/bootstrap.min.css')); ?>">
		<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/line-awesome.css')); ?>">
		<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/line-awesome-font-awesome.min.css')); ?>">
		<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/font-awesome.min.css')); ?>">
		<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/jquery.mCustomScrollbar.min.css')); ?>">
		<link rel="stylesheet" type="text/css" href="<?php echo e(asset('lib/slick/slick.css')); ?>">
		<link rel="stylesheet" type="text/css" href="<?php echo e(asset('lib/slick/slick-theme.css')); ?>">
		<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/style.css')); ?>">
		<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/responsive.css')); ?>">
	</head>


<body>
	

	<div class="wrapper">

		<?php echo $__env->yieldContent('header'); ?>

		<section class="messages-page">
			<div class="container">
				<div class="messages-sec">
					<div class="row">

						<?php echo $__env->yieldContent('user-message'); ?>

						<?php echo $__env->yieldContent('conversation'); ?>

					</div>
				</div>
			</div>
		</section>

	</div><!--theme-layout end-->



	<script type="text/javascript" src="<?php echo e(asset('js/jquery.min.js')); ?>"></script>
	<script type="text/javascript" src="<?php echo e(asset('js/popper.js')); ?>"></script>
	<script type="text/javascript" src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>
	<script type="text/javascript" src="<?php echo e(asset('js/jquery.mCustomScrollbar.js')); ?>"></script>
	<script type="text/javascript" src="<?php echo e(asset('lib/slick/slick.min.js')); ?>"></script>
	<script type="text/javascript" src="<?php echo e(asset('js/scrollbar.js')); ?>"></script>
	<script type="text/javascript" src="<?php echo e(asset('js/script.js')); ?>"></script>
</body>
</html><?php /**PATH C:\ProjetSocial\communitySocial\resources\views/pages/messages/_partials/master.blade.php ENDPATH**/ ?>