<?php $__env->startSection('header-acceuil'); ?>
	
	<?php echo $__env->make('pages.header/header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	
<?php $__env->stopSection(); ?>

<?php $__env->startSection("section_gauche"); ?>

	<div class="col-lg-3 col-md-4 pd-left-none no-pd">
		<div class="main-left-sidebar no-margin">
			<div class="user-data full-width">
				<div class="user-profile">
					<div class="username-dt">
						<div class="usr-pic">
							<!-- <img src="http://via.placeholder.com/100x100" alt=""> -->
							<img src="<?php echo e($user->profil->getPhotoProfile()); ?>" width="100" alt="Photo de profile">
						</div>
					</div><!--username-dt end-->
					<div class="user-specs">
						<h3><?php echo e($user->nom); ?> <?php echo e($user->prenom); ?> </h3>
						<span style="color: blue"><?php echo e($user->job); ?></span>
					</div>
				</div><!--user-profile end-->
				<ul class="user-fw-status">
					<li>
						<h4>Utilisateurs suivi</h4>
						<span>?</span>
					</li>
					<li>
						<h4>Suivi par</h4>
						<span>?</span>
					</li>
					<li>
						<a href="<?php echo e(route('profile',['user' => $user])); ?>" title="">Voir Profile</a>
					</li>
				</ul>
			</div><!--user-data end-->
			<div class="suggestions full-width">
				<div class="sd-title">
					<h3>Suggestions</h3>
					<i class="la la-ellipsis-v"></i>
				</div><!--sd-title end-->
					<div class="suggestions-list">
						<?php $__currentLoopData = $familles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $famil): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<?php if($famil->id != $user->id): ?>
								<div class="suggestion-usd">
									<!-- <img src="http://via.placeholder.com/35x35" alt=""> -->
									<?php if($famil->profil->avatar == ""): ?>
										<img src="<?php echo e(asset('storage/avatars-profil/default.png')); ?>" width="35" alt="">
									<?php else: ?>
										<img src="<?php echo e(asset('storage' . '/' . getAuteurPhoto($famil->profil->user_id))); ?>" width="35" alt="">
									<?php endif; ?>
									<div class="sgt-text">
										<h4><?php echo e($famil->nom); ?> <?php echo e($famil->prenom); ?></h4>
										
									</div>
									<span><i class="la la-plus"></i></span>
								</div>
							<?php endif; ?>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						<div class="view-more">
							<a href="#" title="">Voir plus</a>
						</div>
					</div><!--suggestions-list end-->
				
			</div><!--suggestions end-->
			
		</div><!--main-left-sidebar end-->
	</div>
	
							
<?php $__env->stopSection(); ?>

<?php $__env->startSection("main-ws-sec"); ?>
	
	<div class="col-lg-6 col-md-8 no-pd">
		<div class="main-ws-sec">
			<div class="post-topbar">
				<div class="user-picy">
					<!-- <img src="http://via.placeholder.com/100x100" alt=""> -->
					<img src="<?php echo e($user->profil->getPhotoProfile()); ?>" width="100" alt="Photo de profile">
				</div>
				<div class="post-st">
					<ul>
						<!-- <li><a class="post-pub active" href="#" title="">Exprimez-vous</a></li> -->
						<li><a class="post_project active" href="#" title="">Exprimez-vous</a></li>
						<li><a class="post-jb " href="#" title="">Un Jobs</a></li>
					</ul>
				</div><!--post-st end-->
			</div><!--post-topbar end-->
			<div class="posts-section">
				<?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<div class="post-bar">
						<div class="post_topbar">
							<div class="usy-dt">
								<!-- <img src="http://via.placeholder.com/50x50" alt=""> -->
								<img src="<?php echo e(asset('storage' . '/' . getAuteurPhoto($post->user_id))); ?>" width="50" height="50" alt="">
								<div class="usy-name"> 
									<h3><?php echo e(getAuteurNom($post->user->id)); ?> <?php echo e(getAuteurPrenom($post->user->id)); ?></h3>
									<span>
										<img src="images/clock.png" alt="">
										<?php echo e(Carbon\Carbon::parse($post->created_at)->diffForHumans()); ?>

									</span>
								</div>
							</div>
							<div class="ed-opts">
								<a href="#" title="" class="ed-opts-open">
									<i class="la la-ellipsis-v"></i>
								</a>
								<?php if($user->id == $post->user_id): ?>
									<ul class="ed-options">
										<li><a href="#" title="">Modifier</a></li>
										<li><a href="#" title="">Supprimer</a></li>
										<li><a href="#" title="">Desactiver</a></li>
										
									</ul>
								<?php endif; ?>
							</div>
						</div>
						<div class="epi-sec">
							<ul class="descp">
								<li>
									<img src="images/icon8.png" alt="">
									<span><?php echo e(getAuteurJob($post->user->id)); ?></span>
								</li>
								<li>
									<img src="images/icon9.png" alt="">
									<span> <?php echo e(getAuteurVille($post->user_id)); ?> </span>
								</li>
							</ul>
							<ul class="bk-links">
								<li><a href="#" title=""><i class="la la-bookmark"></i></a></li>
								<li><a href="#" title=""><i class="la la-envelope"></i></a></li>
							</ul>
						</div>
						<div class="job_descp">
							<h3><?php echo e($post->title); ?></h3>
							<p title="<?php echo e($post->content); ?>" class="pa1">
								<?php if(strlen($post->content) >= 100): ?>
									<?php echo e(substr($post->content, 0, 100). "..."); ?>

									<br>
									<a href="#" class="lien_<?php echo e($post->id); ?>" title="">voir plus</a>
								<?php else: ?>
									<?php echo e($post->content); ?>

									<br><br/>
								<?php endif; ?>

								<?php if($post->photo != ""): ?>
									<br><br>
									<img src="<?php echo e(asset('storage' . '/' . $post->photo)); ?>" width="100%">
								<?php endif; ?>

								<?php if($post->video != ""): ?>
									<video title="<?php echo e($post->video); ?>" width="100%" preload="auto" autoplay controls>

										<source src="<?php echo e(asset('files') . '/' .$post->video); ?>" type="video/mp4">
										<source src="<?php echo e(asset('files') . '/' .$post->video); ?>" type="video/ogg">
										<source src="<?php echo e(asset('files') . '/' .$post->video); ?>" type="video/webm">

									</video>
								<?php endif; ?>
							</p>
							<p title="<?php echo e($post->content); ?>" class="pa2">
							
								<?php echo e($post->content); ?>

								<br><br/>

								<?php if($post->photo != ""): ?>
									<br><br>
									<img src="<?php echo e(asset('storage' . '/' . $post->photo)); ?>" width="100%">
								<?php endif; ?>

								<?php if($post->video != ""): ?>
									<video title="<?php echo e($post->title); ?>" width="100%" preload="none" controls>

										<source src="<?php echo e(asset('files') . '/' .$post->video); ?>" type="video/mp4">
										<source src="<?php echo e(asset('files') . '/' .$post->video); ?>" type="video/ogg">
										<source src="<?php echo e(asset('files') . '/' .$post->video); ?>" type="video/webm">

									</video>
								<?php endif; ?>
							</p> 
						</div>
						<div class="job-status-bar">
							<ul class="like-com">
								<li>
									<a href="#"><i class="la la-heart"></i> Like</a>
									<img src="images/liked-img.png" alt="">
									<span>25</span>
								</li> 
								<li><a href="#" title="" class="com"><img src="images/com.png" alt=""> Comment 15</a></li>
							</ul>
							<a><i class="la la-eye"></i>Views 50</a>
						</div>
					</div><!--post-bar end-->
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

				<?php echo e($posts->links()); ?>


				<div class="top-profiles">
					<div class="pf-hd">
						<h3>Top Profiles</h3>
						<i class="la la-ellipsis-v"></i>
					</div>
					<div class="profiles-slider">

						<?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user0): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

							<?php if($user0->id != $user->id): ?>
								<div class="user-profy">
									<!-- <img src="http://via.placeholder.com/57x57" alt=""> -->
									<?php if($user0->profil->avatar == ""): ?>
										<img src="<?php echo e(asset('storage/avatars-profil/default.png')); ?>" width="57" alt="">
									<?php else: ?>
										<img src="<?php echo e(asset('storage' . '/' . $user0->profil->avatar)); ?>" width="57" alt="">
									<?php endif; ?>

									<h3><?php echo e($user0->nom); ?> <?php echo e($user0->prenom); ?></h3>

									

									<ul>
										<li><a href="#" title="" class="followw">Suivre</a></li>
										<li><a href="#" title="" class="envlp"><img src="images/envelop.png" alt=""></a></li>
										<li><a href="#" title="" class="hire">Invité</a></li>
									</ul>
									<a href="<?php echo e(route('voir.profile',['user' => $user0])); ?>">Voir profile</a>
								</div><!--user-profy end-->
							<?php endif; ?>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

					</div><!--profiles-slider end-->
				</div><!--top-profiles end-->
				
				
				<div class="process-comm">
					<div class="spinner">
						<div class="bounce1"></div>
						<div class="bounce2"></div>
						<div class="bounce3"></div>
					</div>
				</div><!--process-comm end-->
			</div><!--posts-section end-->
		</div><!--main-ws-sec end-->
	</div> 

<?php $__env->stopSection(); ?>

<?php $__env->startSection("section_droit"); ?>

	<div class="col-lg-3 pd-right-none no-pd">
		<div class="right-sidebar">
			
			<div class="widget widget-jobs">
				<div class="sd-title">
					<h3>Top Jobs</h3>
					<i class="la la-ellipsis-v"></i>
				</div>
				<div class="jobs-list">
					<div class="job-info">
						<div class="job-details">
							<h3>Maître de maison</h3>
							<p>Besoins d'un répetiteur..</p>
						</div>
						<div class="hr-rate">
							<span>$25/heure</span>
						</div>
					</div><!--job-info end-->
					<div class="job-info">
						<div class="job-details">
							<h3>Développeur</h3>
							<p>Création d'un site vitrine pour une entreprise..</p>
						</div>
						<div class="hr-rate">
							<span>$250/heure</span>
						</div>
					</div><!--job-info end-->
				</div><!--jobs-list end-->
			</div><!--widget-jobs end-->
			
			<div class="widget suggestions full-width">
				<div class="sd-title">
					<h3>Personnes les plus suivies</h3>
					<i class="la la-ellipsis-v"></i>
				</div><!--sd-title end-->
				<div class="suggestions-list">
					<?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<div class="suggestion-usd">
							<!-- <img src="http://via.placeholder.com/35x35" alt=""> -->
							<?php if($user->profil->avatar == ""): ?>
								<img src="<?php echo e(asset('storage/avatars-profil/default.png')); ?>" width="35" alt="">
							<?php else: ?>
								<img src="<?php echo e(asset('storage' . '/' . $user->profil->avatar)); ?>" width="35" alt="">
							<?php endif; ?>

							<div class="sgt-text">
								<h4><?php echo e($user->nom); ?> <?php echo e($user->prenom); ?></h4>
								
							</div>
							<span><i class="la la-plus"></i></span>
						</div>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</div><!--suggestions-list end-->
			</div>
		</div><!--right-sidebar end-->
	</div> 

<?php $__env->stopSection(); ?>



<?php $__env->startSection("form-post"); ?>
	<?php echo $__env->make('pages.posts.create', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>


<?php $__env->startSection("form-post-jobs"); ?>
	<?php echo $__env->make('pages.jobs.create', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>




<?php echo $__env->make("../layouts.master", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\ProjetSocial\communitySocial\resources\views/pages/index.blade.php ENDPATH**/ ?>