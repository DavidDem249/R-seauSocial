<div class="product-feed-tab" id="info-dd">

	<?php if(Session::has('success')): ?>
        <div class="alert alert-success" align="center"><?php echo e(Session::get('success')); ?></div>
    <?php endif; ?>

    <?php if(Session::has('errors')): ?>
        <div class="alert alert-success" align="center"><?php echo e(Session::get('errors')); ?></div>
    <?php endif; ?>


	<div class="user-profile-ov">

		<h3>
			<a href="#" title="" class="lct-box-open">Info perso</a> 

			<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update',$user->profil)): ?>
				<a href="#" title="" class="lct-box-open">
					<i class="fa fa-pencil"></i>
				</a> 

				<a href="#" title="">
					<i class="fa fa-plus-square"></i>
				</a>
			<?php endif; ?>

		</h3>
		<h4 style="background-color: green; color:#fff">Côte d'ivoire</h4>

		<p>Nom: <span style="font-weight: bold;"> <?php echo e($user->nom); ?></span></p>
		<p>Prénom: <span style="font-weight: bold;"> <?php echo e($user->prenom); ?> </span></p>
		<p>Email: <span style="font-weight: bold;"> <?php echo e($user->email); ?></span></p>

		<?php if($user->profil->contact ==""): ?>
			<p>Contact: <span style="font-weight: bold;"> ? </span></p>
		<?php else: ?>
			<p>Contact: <span style="font-weight: bold;"> <?php echo e($user->profil->contact); ?></span></p>
		<?php endif; ?>
		
		<p>Ville: <span style="font-weight: bold;"> <?php echo e($user->adresse); ?></span></p>
		<p>Genre: <span style="font-weight: bold;"> <?php echo e($user->genre); ?></span></p>

		<?php if($user->profil->date_naissance ==""): ?>
			<p>Date de naissance: <span style="font-weight: bold;"> ? </span></p>
		<?php else: ?>
			<p>Date de naissance: <span style="font-weight: bold;"> <?php echo e($user->profil->date_naissance); ?></span></p>
		<?php endif; ?>

		<?php if($user->profil->job ==""): ?>
			<p>Job: <span style="font-weight: bold;"> ? </span></p>
		<?php else: ?>
			<p>Job: <span style="font-weight: bold;"> <?php echo e($user->profil->job); ?></span></p>
		<?php endif; ?>
		
	</div><!--user-profile-ov end-->

	<div class="user-profile-ov">
		<h3><a href="#" title="" class="overview-open">
				Biographie
			</a> 
			<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update',$user->profil)): ?>
				<a href="#" title="" class="overview-open">
					<i class="fa fa-pencil"></i>
				</a>
			<?php endif; ?>
		</h3>
		<?php if($user->profil->biographie == ""): ?>

			<p> ? </p>

		<?php else: ?>

			<p><?php echo e($user->profil->biographie); ?></p>

		<?php endif; ?>

	</div><!--user-profile-ov end-->

	<div class="user-profile-ov">
		<h3>
			<a href="#" title="" class="skills-open">
				Infos familiale
			</a> 
			<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update',$user->profil)): ?>
				<a href="#" title="" class="skills-open">
					<i class="fa fa-pencil"></i>
				</a> 
				<a href="#">
					<i class="fa fa-plus-square"></i>
				</a>
			<?php endif; ?>
		</h3>

		<?php if($user->genre == "Masculin"): ?>

			<?php if($user->profil->nom_prenom_pere == "" and $user->nom_prenom_mere == ""): ?>

				<p>Fils de <span style="font-weight: bold;"> ? </span> et de <span style="font-weight: bold;"> ? </span></p>

			<?php else: ?>

				<p>Fils de <span style="font-weight: bold;"> <?php echo e($user->profil->nom_prenom_pere); ?></span> et de <span style="font-weight: bold;"><?php echo e($user->profil->nom_prenom_mere); ?></span></p>

			<?php endif; ?>

		<?php else: ?>

			<?php if($user->profil->nom_prenom_pere == "" and $user->nom_prenom_mere == ""): ?>

				<p>Fille de <span style="font-weight: bold;"> ? </span> et de <span style="font-weight: bold;"> ? </span></p>

			<?php else: ?>

				<p>Fille de <span style="font-weight: bold;"> <?php echo e($user->profil->nom_prenom_pere); ?></span> et de <span style="font-weight: bold;"><?php echo e($user->profil->nom_prenom_mere); ?> </span></p>

			<?php endif; ?>

		<?php endif; ?>

		
	</div><!--user-profile-ov end-->


	
	
</div><?php /**PATH C:\ProjetSocial\communitySocial\resources\views/pages/profiles/_partials/infos.blade.php ENDPATH**/ ?>