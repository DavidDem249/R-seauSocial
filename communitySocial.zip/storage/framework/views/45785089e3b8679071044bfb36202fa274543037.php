<?php $__env->startSection('header'); ?>
	<?php echo $__env->make('pages.profiles._partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><!--header end-->
<?php $__env->stopSection(); ?>
	
<?php $__env->startSection('user-message'); ?>

	<?php echo $__env->make('pages.messages._partials.user-message',['users' => $users, 'unread' => $unread], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('pages.messages._partials.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\ProjetSocial\communitySocial\resources\views/pages/messages/create.blade.php ENDPATH**/ ?>