<div class="sign_in_sec" id="tab-2">
	<div class="signup-tab">
		<i class="fa fa-long-arrow-left"></i>
		<h2>Inscription</h2>
		<ul>
			<li data-tab="tab-3" class="current"><a href="#" title="">Utilisateur</a></li>
			
		</ul>
	</div><!--signup-tab end-->	
	<div class="dff-tab current" id="tab-3">
		<form method="POST" action="<?php echo e(route('register')); ?>">

			<?php echo csrf_field(); ?> 
			
			<div class="row">
				<div class="col-lg-12 no-pdd">
					<div class="sn-field">
						<input type="text" name="nom" class="form-control" placeholder="Nom" value="<?php echo e(old('nom')); ?>">
						<i class="la la-user"></i>
					</div>

					<?php if($errors->first('nom')): ?>
						<p style="color:#CD3F3F;"><?php echo e($errors->first('nom')); ?></p>
					<?php endif; ?>
				</div>
				<div class="col-lg-12 no-pdd">
					<div class="sn-field">
						<input type="text" name="prenom" class="form-control" placeholder="Prénom" value="<?php echo e(old('prenom')); ?>">
						<i class="la la-user"></i>
					</div>

					<?php if($errors->first('prenom')): ?>
						<p style="color:#CD3F3F;"><?php echo e($errors->first('prenom')); ?></p>
					<?php endif; ?>
				</div>
				<div class="col-lg-12 no-pdd">
					<div class="sn-field">
						<input type="text" name="adresse" class="form-control" placeholder="Votre ville" value="<?php echo e(old('adresse')); ?>">
						<i class="la la-map"></i>
					</div>

					<?php if($errors->first('adresse')): ?>
						<p style="color:#CD3F3F;"><?php echo e($errors->first('adresse')); ?></p>
					<?php endif; ?>
				</div>
				<div class="col-lg-12 no-pdd">
					<div class="sn-field">
						<select name="genre" class="form-control">
							<option value="">Genre</option>
							<option value="Masculin">Masculin</option>
							<option value="Féminin">Féminin</option>
							<option value="Autre">Autre</option>
						</select>
						<i class="la la-dropbox"></i>
						<span><i class="fa fa-ellipsis-h"></i></span>
					</div>

					<?php if($errors->first('genre')): ?>
						<p style="color:#CD3F3F;"><?php echo e($errors->first('genre')); ?></p>
					<?php endif; ?>
				</div>
				
				<div class="col-lg-12 no-pdd">
					<div class="sn-field">
						<input type="email" name="email" class="form-control" placeholder="Email" value="<?php echo e(old('email')); ?>">
						<i class="la la-envelope"></i>
					</div>

					<?php if($errors->first('email')): ?>
						<p style="color:#CD3F3F;"><?php echo e($errors->first('email')); ?></p>
					<?php endif; ?>
				</div>

				

				<div class="col-lg-12 no-pdd">
					<div class="sn-field">
						<input type="password" name="password" class="form-control" placeholder="Mot de passe" value="">
						<i class="la la-lock"></i>
					</div>

					<?php if($errors->first('password')): ?>
						<p style="color:#CD3F3F;"><?php echo e($errors->first('password')); ?></p>
					<?php endif; ?>
				</div>
				<div class="col-lg-12 no-pdd">
					<div class="sn-field">
						<input type="password" name="password_conf" class="form-control" placeholder="Confirmé mot de passe" value="">
						<i class="la la-lock"></i>
					</div>

					<?php if($errors->first('password_conf')): ?>
						<p style="color:#CD3F3F;"><?php echo e($errors->first('password_conf')); ?></p>
					<?php endif; ?>
				</div>
				
				<div class="col-lg-12 no-pdd">
					<button type="submit" value="submit">S'inscrire</button>
				</div>
			</div>
		</form>
	</div><!--dff-tab end-->
	
</div>	
<?php /**PATH C:\ProjetSocial\communitySocial\resources\views/pages/auths/signup.blade.php ENDPATH**/ ?>