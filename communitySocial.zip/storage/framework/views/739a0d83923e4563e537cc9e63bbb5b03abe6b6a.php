
<div class="product-feed-tab current" id="feed-dd">
	<div class="posts-section">
		<?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<div class="post-bar">
				<div class="post_topbar">
					<div class="usy-dt">
						<!-- <img src="http://via.placeholder.com/50x50" alt=""> -->
						<img src="<?php echo e(asset('storage' . '/' . getAuteurPhoto($post->user_id))); ?>" width="50" height="50" alt="">

						<div class="usy-name">
							<h3><?php echo e($post->user->nom); ?>  <?php echo e($post->user->prenom); ?></h3>
							<span>
								<img src="<?php echo e(asset('images/clock.png')); ?>" alt="">
								<?php echo e(Carbon\Carbon::parse($post->created_at)->diffForHumans()); ?>

							</span>
						</div>
					</div>
					<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update',$user->profil)): ?>
						<div class="ed-opts">
							<a href="#" title="" class="ed-opts-open"><i class="la la-ellipsis-v"></i></a>
							<ul class="ed-options">
								<li><a href="#" title="">Modifier</a></li>
								<li><a href="#" title="">Supprimer</a></li>
								<li><a href="#" title="">Desactiver</a></li>
								
							</ul>
						</div>
					<?php endif; ?>
				</div>
				<div class="epi-sec">
					<ul class="descp">
						<li><img src="<?php echo e(asset('images/icon8.png')); ?>" alt="">
							<span><?php echo e($user->profil->job); ?></span>
						</li>
						<li>
							<img src="<?php echo e(asset('images/icon9.png')); ?>" alt="">
							<span><?php echo e($user->adresse); ?></span>
						</li>
					</ul>
					
				</div>
				<div class="job_descp">
					<h3><?php echo e($post->title); ?></h3>

					<p>
						<?php if(strlen($post->content) >= 600): ?>
							<?php echo e(substr($post->content, 0, 100). "..."); ?>

							<br>
							<a href="#" title="">voir plus</a>
						<?php else: ?>
							<?php echo e($post->content); ?>

							<br><br/>
						<?php endif; ?>

						<?php if($post->photo != ""): ?>
							<img src="<?php echo e(asset('storage' . '/' . $post->photo)); ?>" width="500" height="200">
						<?php endif; ?>

						<?php if($post->video != ""): ?>
							<video title="<?php echo e($post->title); ?>" width="100%" preload="auto" autoplay controls>

								<source src="<?php echo e(asset('files') . '/' .$post->video); ?>" type="video/mp4">
								<source src="<?php echo e(asset('files') . '/' .$post->video); ?>" type="video/ogg">
								<source src="<?php echo e(asset('files') . '/' .$post->video); ?>" type="video/webm">

							</video>
						<?php endif; ?>
						
					</p>
					
				</div>
				<div class="job-status-bar">
					<ul class="like-com">
						<li>
							<a href="#"><i class="la la-heart"></i> Like</a>
							<img src="<?php echo e(asset('images/liked-img.png')); ?>" alt="">
							<span>25</span>
						</li> 
						<li><a href="#" title="" class="com"><img src="<?php echo e(asset('images/com.png')); ?>" alt=""> Comment 15</a></li>
					</ul>
					<a><i class="la la-eye"></i>Views 50</a>
				</div>
			</div><!--post-bar end-->
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		<div class="process-comm">
			<div class="spinner">
				<div class="bounce1"></div>
				<div class="bounce2"></div>
				<div class="bounce3"></div>
			</div>
			<!-- <a href="#" title=""><img src="<?php echo e(asset('images/process-icon.png')); ?>" alt=""></a> -->
		</div><!--process-comm end-->
	</div><!--posts-section end-->
</div>

<?php /**PATH C:\ProjetSocial\communitySocial\resources\views/pages/profiles/_partials/posts.blade.php ENDPATH**/ ?>