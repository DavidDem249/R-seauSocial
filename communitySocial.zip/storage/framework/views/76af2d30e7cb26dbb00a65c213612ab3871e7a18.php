
<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<title>Profiles</title>
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<link rel="icon" href="<?php echo e(asset('images/cmp-icon5.png')); ?>" type="image/x-icon">
		<meta name="description" content="" />
		<meta name="keywords" content="" />
		<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/animate.css')); ?>">
		<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/bootstrap.min.css')); ?>">
		<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/flatpickr.min.css')); ?>">
		<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/line-awesome.css')); ?>">
		<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/line-awesome-font-awesome.min.css')); ?>">
		<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/font-awesome.min.css')); ?>">
		<link rel="stylesheet" type="text/css" href="<?php echo e(asset('lib/slick/slick.css')); ?>">
		<link rel="stylesheet" type="text/css" href="<?php echo e(asset('lib/slick/slick-theme.css')); ?>">
		<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/style.css')); ?>">
		<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/responsive.css')); ?>">
	</head>


	<body>
	

		<div class="wrapper">
			
			<?php echo $__env->make('pages.profiles._partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><!--header end-->

			<section class="companies-info">
				<div class="container">
					<div class="company-title">
						<h3>Tous les profiles</h3>
					</div><!--company-title end-->
					<div class="companies-list">
						<div class="row">

							<?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<?php if($user->id != $userConnect->id): ?>
									<div class="col-lg-3 col-md-4 col-sm-6 col-12">
										<div class="company_profile_info">
											<div class="company-up-info">
												<!-- <img src="http://via.placeholder.com/91x91" alt=""> -->
												<?php if($user->profil->avatar == ""): ?>
													<img src="<?php echo e(asset('storage/avatars-profil/default.png')); ?>" alt="">
												<?php else: ?>
													<img src="<?php echo e(asset('storage' . '/' . $user->profil->avatar)); ?>" alt="">
												<?php endif; ?>
												<h3><?php echo e($user->nom); ?> <?php echo e($user->prenom); ?></h3>
												
												<?php if($user->profil->job == ""): ?>
													<h4 style="color: red"> Pas de job indiqué  </h4>
												<?php else: ?>
													<h4><?php echo e($user->profil->job); ?></h4>
												<?php endif; ?>
												<ul>
													<li><a href="#" title="" class="follow">Suivre</a></li>
													<li><a href="#" title="" class="message-us"><i class="fa fa-envelope"></i></a></li>
													<li><a href="#" title="" class="hire-us">Invité</a></li>
												</ul>
											</div>
											<a href=" <?php echo e(route('voir.profile',['user' => $user])); ?> " title="" class="view-more-pro">Voir profile</a>
										</div><!--company_profile_info end-->
									</div>
								<?php endif; ?>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

						</div>
					</div><!--companies-list end-->
					<div class="process-comm">
						<div class="spinner">
							<div class="bounce1"></div>
							<div class="bounce2"></div>
							<div class="bounce3"></div>
						</div>
					</div>
				</div>
			</section><!--companies-info end-->


		</div><!--theme-layout end-->



		<script type="text/javascript" src="<?php echo e(asset('js/jquery.min.js')); ?>"></script>
		<script type="text/javascript" src="<?php echo e(asset('js/popper.js')); ?>"></script>
		<script type="text/javascript" src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>
		<script type="text/javascript" src="<?php echo e(asset('js/flatpickr.min.js')); ?>"></script>
		<script type="text/javascript" src="<?php echo e(asset('lib/slick/slick.min.js')); ?>"></script>
		<script type="text/javascript" src="<?php echo e(asset('js/script.js')); ?>"></script>
	</body>
</html><?php /**PATH C:\ProjetSocial\communitySocial\resources\views/pages/profiles/profiles_users.blade.php ENDPATH**/ ?>