
<?php /**PATH C:\ProjetSocial\communitySocial\resources\views/pages/profiles/_partials/portefolio.blade.php ENDPATH**/ ?>