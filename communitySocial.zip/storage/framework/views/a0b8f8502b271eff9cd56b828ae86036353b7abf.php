<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<title>Authentification</title>
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<meta name="description" content="" />
		<meta name="keywords" content="" />
		<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/animate.css')); ?>">
		<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/bootstrap.min.css')); ?>">
		<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/line-awesome.css')); ?>">
		<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/line-awesome-font-awesome.min.css')); ?>">
		<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/font-awesome.min.css')); ?>">
		<link rel="stylesheet" type="text/css" href="<?php echo e(asset('lib/slick/slick.css')); ?>">
		<link rel="stylesheet" type="text/css" href="<?php echo e(asset('lib/slick/slick-theme.css')); ?>">
		<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/style.css')); ?>">
		<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/responsive.css')); ?>">
	</head>


	<body class="sign-in">
	

	<div class="wrapper">

		<div class="sign-in-page">
			<div class="signin-popup">
				<div class="signin-pop">
					<div class="row">
						<div class="col-lg-5">
							<div class="cmp-info">
								<div class="cm-logo">
									<img src="" alt="logo-social-community">
									<p>Social community,  est une plateforme de réseau social qui à pour but de rapprocher une famille de façon virtuelle, rétrouver ses parents éloigné et bien d'autres</p>
								</div><!--cm-logo end-->	
								<img src="<?php echo e(asset('images/cm-main-img.png')); ?>" alt="">		
							</div><!--cmp-info end-->
						</div>
						<div class="col-lg-7">
							<div class="login-sec">
								

								<?php echo $__env->yieldContent('sign_in_sec-login'); ?>

								<?php echo $__env->yieldContent("sign_in_sec-register"); ?>

								<?php echo $__env->yieldContent("password_forgot"); ?>

							</div>
						</div>
					</div>
				</div>
			</div>

			<?php echo $__env->yieldContent('footy-sec'); ?>

		</div>

	</div>

		<script type="text/javascript" src="<?php echo e(asset('js/jquery.min.js')); ?>"></script>
		<script type="text/javascript" src="<?php echo e(asset('js/popper.js')); ?>"></script>
		<script type="text/javascript" src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>
		<script type="text/javascript" src="<?php echo e(asset('lib/slick/slick.min.js')); ?>"></script>
		<script type="text/javascript" src="<?php echo e(asset('js/script.js')); ?>"></script>
	</body>
</html><?php /**PATH C:\ProjetSocial\communitySocial\resources\views/pages/auths/_partials/master.blade.php ENDPATH**/ ?>