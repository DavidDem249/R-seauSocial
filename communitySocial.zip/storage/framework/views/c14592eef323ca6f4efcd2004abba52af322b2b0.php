<div class="post-popup job_post">
	<div class="post-project">
		<h3>Poster un job</h3>
		<div class="post-project-fields">
			
			<div>
				Patientez-svp, nous travaillons dur pour vous satisfaire !
			</div>
		</div><!--post-project-fields end-->
		<a href="#" title=""><i class="la la-times-circle-o"></i></a>
	</div><!--post-project end-->
</div><!--post-project-popup end-->
<?php /**PATH C:\ProjetSocial\communitySocial\resources\views/pages/jobs/create.blade.php ENDPATH**/ ?>