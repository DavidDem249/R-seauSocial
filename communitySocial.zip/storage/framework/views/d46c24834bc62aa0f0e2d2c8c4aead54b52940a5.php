<div class="main-left-sidebar">
	<div class="user_profile">
		<div class="user-pro-img">
			<!-- <img src="http://via.placeholder.com/170x170" alt=""> -->
			<img src="<?php echo e($user->profil->getPhotoProfile()); ?>" width="200" alt="Photo de profile">
			<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update', $user->profil)): ?>
				<a href="#" class="box-photo" title="">
					<i class="fa fa-camera"></i>
				</a>
			<?php endif; ?>
		</div><!--user-pro-img end-->
		<div class="user_pro_status">
			<ul class="flw-hr">
				<li><a href="#" title="" class="flww"><i class="la la-plus"></i> Follow</a></li>
				<li><a href="#" title="" class="hre">Hire</a></li>
			</ul>
			<ul class="flw-status">
				<li>
					<span>Following</span>
					<b>34</b>
				</li>
				<li>
					<span>Followers</span>
					<b>155</b>
				</li>
			</ul>
		</div><!--user_pro_status end-->
		<ul class="social_links">
			

			<li><a href="<?php echo e($user->profil->facebook); ?>" target="_blank" title=""><i class="fa fa-facebook-square"></i> <?php echo e($user->profil->facebook); ?> </a></li>

			<li><a href="<?php echo e($user->profil->twitter); ?>" target="_blank" title=""><i class="fa fa-twitter"></i> <?php echo e($user->profil->twitter); ?></a></li>

			
			
			

			<li>
				<a href="<?php echo e($user->profil->instagram); ?>" target="_blank" title="">
					<i class="fa fa-instagram"></i> 
					<?php echo e($user->profil->instagram); ?>

				</a>
			</li>

			
		</ul>
	</div><!--user_profile end-->
	<div class="suggestions full-width">
		<div class="sd-title">
			<h3>Vos amis</h3>
			<i class="la la-ellipsis-v"></i>
		</div><!--sd-title end-->
		
	</div><!--suggestions end-->
</div><?php /**PATH C:\ProjetSocial\communitySocial\resources\views/pages/profiles/_partials/left_sidebar.blade.php ENDPATH**/ ?>