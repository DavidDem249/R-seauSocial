<div class="main-ws-sec">
	<div class="user-tab-sec">
		<h3><?php echo e($user->nom); ?>  <?php echo e($user->prenom); ?></h3>
		<div class="star-descp">
			<span><?php echo e($user->profil->job); ?> </span>
			<ul>
				<li><i class="fa fa-star"></i></li>
				<!-- <li><i class="fa fa-star"></i></li> -->
				<li><i class="fa fa-star-half-o"></i></li>
			</ul>
			<!-- <a href="#" title="">Status</a> -->
		</div><!--star-descp end-->
		<div class="tab-feed st2">
			<ul>
				<li data-tab="feed-dd" class="active">
					<a href="#" title="">
						<img src="<?php echo e(asset('images/ic1.png')); ?>" alt="">
						<span>Les postes</span>
					</a>
				</li>
				<li data-tab="info-dd">
					<a href="#" title="">
						<img src="<?php echo e(asset('images/ic2.png')); ?>" alt="">
						<span>Informations</span>
					</a>
				</li>
				<li data-tab="saved-jobs">
					<a href="#" title="">
						<img src="<?php echo e(asset('images/ic4.png')); ?>" alt="">
						<span>Les jobs publiés</span>
					</a>
				</li>
				
				<li data-tab="portfolio-dd">
					<a href="#" title="">
						<img src="<?php echo e(asset('images/ic3.png')); ?>" alt="">
						<span>Portfolio</span>
					</a>
				</li>
				
			</ul>

		</div><!-- tab-feed end-->
	</div><!--user-tab-sec end-->
	<?php echo $__env->make('pages.profiles._partials.posts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	<!--product-feed-tab end-->
	
	<?php echo $__env->make('pages.profiles._partials.infos', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	<!--product-feed-tab end-->

	<?php echo $__env->make('pages.profiles._partials.jobs', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	<!--product-feed-tab end-->

	
	
	<?php echo $__env->make('pages.profiles._partials.portefolio', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	<!--product-feed-tab end-->
	
	
</div><?php /**PATH C:\ProjetSocial\communitySocial\resources\views/pages/profiles/_partials/ws-sec.blade.php ENDPATH**/ ?>