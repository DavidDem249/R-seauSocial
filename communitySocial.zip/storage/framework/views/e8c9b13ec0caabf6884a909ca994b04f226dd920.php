<?php $__env->startSection('sign_in_sec-login'); ?>
	<ul class="sign-control">
		<li data-tab="tab-1" class="current"><a href="#" title="">Connexion</a></li>				
		<li data-tab="tab-2"><a href="#" title="">Inscription</a></li>				
	</ul>
	
	<div class="sign_in_sec current" id="tab-1">
		<?php if(Session::has('success')): ?>
            <div class="alert alert-success" align="center"><?php echo e(Session::get('success')); ?></div>
        <?php endif; ?>
		<h3>Connexion</h3>
		<form method="post" action="<?php echo e(route('login')); ?>">
			<?php echo csrf_field(); ?>
			
			
			<?php if(Session::has('erreur_con')): ?>
				<div class="alert alert-danger">
					<?php echo e(Session::get('erreur_con')); ?>

				</div>
			<?php endif; ?>

			<?php if(Session::has('erreur_ins')): ?>
				<div class="alert alert-danger">
					<?php echo e(Session::get('erreur_ins')); ?>

				</div>
			<?php endif; ?>

			<div class="row">
				<div class="col-lg-12 no-pdd">
					<div class="sn-field">
						<input type="email" class="form-control" name="email" placeholder="Votre email">
						<i class="la la-user"></i>
					</div><!--sn-field end-->
					<?php if($errors->first('email')): ?>
						<p style="color:#CD3F3F;"><?php echo e($errors->first('email')); ?></p>
					<?php endif; ?>
				</div>
				<div class="col-lg-12 no-pdd">
					<div class="sn-field">
						<input type="password" class="form-control" name="password" placeholder="Votre nouveau mot de passe">
						<i class="la la-lock"></i>
					</div>
					<?php if($errors->first('password')): ?>
						<p style="color:#CD3F3F;"><?php echo e($errors->first('password')); ?></p>
					<?php endif; ?>
				</div>
				<div class="col-lg-12 no-pdd">
					<div class="checky-sec">
						<a href="<?php echo e(route('form_pass_forgot')); ?>" title="">Mot de passe oublié</a>
					</div>
				</div>
				<div class="col-lg-12 no-pdd">
					<button type="submit" value="submit">Connexion</button>
				</div>
			</div>
		</form>
		<div class="login-resources">
			<h4>Se connecter à travers ?</h4>
			<ul>
				<li><a href="<?php echo e(url('/redirect')); ?>" class="fb"><i class="fa fa-facebook"></i>Facebook</a></li>
				<li><a href="#" title="" class="tw"><i class="fa fa-twitter"></i>Twitter</a></li>
			</ul>
		</div><!--login-resources end-->
	</div><!--sign_in_sec end-->
			
<?php $__env->stopSection(); ?>

<?php $__env->startSection('sign_in_sec-register'); ?>
	<?php echo $__env->make("pages.auths.signup", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>	
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footy-sec'); ?>
	<div class="footy-sec">
		<div class="container">
			
			<ul>
				<p><img src="<?php echo e(asset('images/copy-icon.png')); ?>" alt="">Copyright 2018</p>	
			</ul>
		</div>
	</div><!--footy-sec end-->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('pages.auths._partials.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\ProjetSocial\communitySocial\resources\views/pages/auths/sigin.blade.php ENDPATH**/ ?>