<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<title>Social community</title>
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<meta name="description" content="" />
		<meta name="keywords" content="" />
		<link rel="icon" href="<?php echo e(asset('images/cmp-icon5.png')); ?>" type="image/x-icon">
		<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/animate.css')); ?>">
		<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/bootstrap.min.css')); ?>">
		<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/line-awesome.css')); ?>">
		<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/line-awesome-font-awesome.min.css')); ?>">
		<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/font-awesome.min.css')); ?>">
		<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/jquery.mCustomScrollbar.min.css')); ?>">
		<link rel="stylesheet" type="text/css" href="<?php echo e(asset('lib/slick/slick.css')); ?>">
		<link rel="stylesheet" type="text/css" href="<?php echo e(asset('lib/slick/slick-theme.css')); ?>">
		<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/line-awesome-font-awesome.min.css')); ?>">
		<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/style.css')); ?>">
		<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/responsive.css')); ?>">


	</head>

	<body>

		<div class="wrapper">

			<?php echo $__env->yieldContent('header-acceuil'); ?>

			<?php echo $__env->yieldContent('password_forgot'); ?>			

			<main>
				<?php if(Session::has('success')): ?>
					<div class="alert alert-success" align="center"><?php echo e(Session::get('success')); ?></div>
				<?php endif; ?>
				<div class="main-section">
					<div class="container">
						<div class="main-section-data">
							<div class="row">

								<?php echo $__env->yieldContent('section_gauche'); ?>

								<?php echo $__env->yieldContent("main-ws-sec"); ?>

								<?php echo $__env->yieldContent("section_droit"); ?>

							</div>
						</div>
					</div>
				</div>
			</main>

			

			<?php echo $__env->yieldContent("form-post"); ?>


			<?php echo $__env->yieldContent('form-post-jobs'); ?>

			
			<?php echo $__env->yieldContent('profile-image-change'); ?>

			

		</div><!--theme-layout end-->

		<script type="text/javascript" src="<?php echo e(asset('js/jquery.min.js')); ?>"></script>
		<script type="text/javascript" src="<?php echo e(asset('js/popper.js')); ?>"></script>
		<script type="text/javascript" src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>
		<script type="text/javascript" src="<?php echo e(asset('js/jquery.mCustomScrollbar.js')); ?>"></script>
		<script type="text/javascript" src="<?php echo e(asset('lib/slick/slick.min.js')); ?>"></script>
		<script type="text/javascript" src="<?php echo e(asset('js/scrollbar.js')); ?>"></script>
		<script type="text/javascript" src="<?php echo e(asset('js/script.js')); ?>"></script>


		<?php echo $__env->make('../pages.scripts.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	</body>
</html><?php /**PATH C:\ProjetSocial\communitySocial\resources\views////layouts/master.blade.php ENDPATH**/ ?>